package net.arena.stormfang;

import net.arena.stormfang.item.StormfangItem;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/** Server-side particle bursts; visible to every nearby client, no extra packets needed. */
public final class StormFx {
	private StormFx() {
	}

	/** Big burst at the Thunderclap strike point. */
	public static void thunderStrike(class_3218 level, class_243 p) {
		level.method_65096(class_2398.field_29644,
				p.field_1352, p.field_1351 + 0.7, p.field_1350, 70, 1.3, 1.6, 1.3, 0.4);
		level.method_65096(StormfangMod.STORM_SPARK,
				p.field_1352, p.field_1351 + 1.0, p.field_1350, 30, 1.1, 1.8, 1.1, 0.05);
		level.method_65096(class_2398.field_11207,
				p.field_1352, p.field_1351 + 0.4, p.field_1350, 25, 1.4, 0.9, 1.4, 0.02);
		level.method_65096(class_2398.field_11237,
				p.field_1352, p.field_1351 + 0.2, p.field_1350, 12, 0.8, 0.4, 0.8, 0.04);
	}

	/** Small zap around an entity hit by the blade. */
	public static void hitZap(class_3218 level, class_243 p, float entityHeight) {
		level.method_65096(class_2398.field_29644,
				p.field_1352, p.field_1351 + entityHeight * 0.6, p.field_1350, 18, 0.45, 0.6, 0.45, 0.1);
		level.method_65096(StormfangMod.STORM_SPARK,
				p.field_1352, p.field_1351 + entityHeight * 0.75 + 0.2, p.field_1350, 8, 0.35, 0.5, 0.35, 0.04);
	}
}
