package net.arena.stormfang.mixin;

import net.arena.stormfang.StormFx;
import net.arena.stormfang.StormfangMod;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Every hit with Stormfang crackles with electricity; 35% chance to summon a bolt
 * on the victim and knock it into the air ("storm proc").
 */
@Mixin(class_1309.class)
public class LivingEntityHurtMixin {
	// 1.21.2+: LivingEntity#hurt(DamageSource,float) was split into hurtServer(ServerLevel,...)
	@Inject(method = "hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At("HEAD"))
	private void stormfang$stormOnHit(class_3218 serverLevel, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
		class_1309 self = (class_1309) (Object) this;
		class_1937 level = self.method_37908();
		if (!(source.method_5529() instanceof class_1657 attacker)) {
			return;
		}
		if (!attacker.method_6047().method_31574(StormfangMod.STORMFANG)) {
			return;
		}

		class_243 p = self.method_19538();
		StormFx.hitZap(serverLevel, p, self.method_17682());

		if (level.method_8409().method_43057() < 0.35F) {
			class_1538 bolt = new class_1538(class_1299.field_6112, level);
			bolt.method_5814(self.method_23317(), self.method_23318() + 0.4, self.method_23321());
			level.method_8649(bolt);
			StormFx.thunderStrike(serverLevel, p.method_1031(0.0, 0.3, 0.0));
			self.method_5762(0.0, 0.45, 0.0);
			StormfangMod.LOGGER.info("[Stormfang] Storm proc on '{}' (hit for {} dmg)",
					self.method_5477().getString(), String.format("%.1f", amount));
		}
	}
}
