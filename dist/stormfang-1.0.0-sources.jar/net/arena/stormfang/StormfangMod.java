package net.arena.stormfang;

import net.arena.stormfang.item.StormfangItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StormfangMod implements ModInitializer {
	public static final String MOD_ID = "stormfang";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}

	/** Custom spark particle — behaviour provided client-side (see StormfangClient). */
	public static final class_2400 STORM_SPARK = class_2378.method_10230(
			class_7923.field_41180, id("storm_spark"), FabricParticleTypes.simple());

	/** Procedurally synthesized thunder charge sound (assets/stormfang/sounds). */
	public static final class_3414 THUNDER_CHARGE = class_2378.method_10230(
			class_7923.field_41172, id("thunder_charge"),
			class_3414.method_47908(id("thunder_charge")));

	public static final class_1792 STORMFANG = new StormfangItem(StormfangItem.KEY);

	public static final class_5321<class_1761> STORMFANG_TAB_KEY =
			class_5321.method_29179(class_7924.field_44688, id("stormfang"));

	@Override
	public void onInitialize() {
		class_2378.method_39197(class_7923.field_41178, StormfangItem.KEY, STORMFANG);

		class_2378.method_39197(class_7923.field_44687, STORMFANG_TAB_KEY, FabricItemGroup.builder()
				.method_47320(() -> new class_1799(STORMFANG))
				.method_47321(class_2561.method_43471("itemGroup.stormfang"))
				.method_47324());

		ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202)
				.register(entries -> entries.method_45421(STORMFANG));
		ItemGroupEvents.modifyEntriesEvent(STORMFANG_TAB_KEY)
				.register(entries -> entries.method_45421(STORMFANG));

		LOGGER.info("[Stormfang] Stormblade forged: item='{}', spark particle + thunder sound loaded.",
				class_7923.field_41178.method_10221(STORMFANG));

		// CI-harness convenience, gated behind -Dstormfang.ciop=1 (never set in normal play):
		// auto-op whoever joins so the headless client's /give works. Reflection avoids
		// coupling to a specific Mojang-mapping method name for the operator list.
		if (System.getProperty("stormfang.ciop") != null) {
			net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
				com.mojang.authlib.GameProfile profile = handler.method_32311().method_7334();
				net.minecraft.class_3324 list = server.method_3760();
				for (java.lang.reflect.Method m : list.getClass().getMethods()) {
					String n = m.getName();
					Class<?>[] pts = m.getParameterTypes();
					try {
						if (n.equals("addOp") && pts.length == 1 && pts[0] == com.mojang.authlib.GameProfile.class) {
							m.invoke(list, profile);
							LOGGER.info("[Stormfang-CI] opped {}", profile.getName());
							break;
						}
						if (n.equals("setOpped") && pts.length == 2 && pts[0] == com.mojang.authlib.GameProfile.class
								&& pts[1] == boolean.class) {
							m.invoke(list, profile, true);
							LOGGER.info("[Stormfang-CI] opped {}", profile.getName());
							break;
						}
					} catch (Throwable ignored) { }
				}
			});
		}
	}
}
