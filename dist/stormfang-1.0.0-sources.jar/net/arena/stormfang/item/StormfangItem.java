package net.arena.stormfang.item;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.arena.stormfang.StormFx;
import net.arena.stormfang.StormfangMod;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1829;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9334;
import net.minecraft.class_9886;
import java.util.Optional;

/**
 * Stormfang — legendary storm blade.
 * <p>
 * - netherite base, +5 attack damage, faster than netherite sword<br>
 * - animated 512px texture (lightning pulse crawls along the fuller) + enchantment glint<br>
 * - right-click: Thunderclap — raycast lightning up to 40 blocks, particles + synthesized sound<br>
 * - passive: every hit crackles; 35% chance to smite the target with a bolt (see LivingEntityHurtMixin)
 */
public class StormfangItem extends class_1829 {
	public static final class_5321<class_1792> KEY = class_5321.method_29179(class_7924.field_41197, StormfangMod.id("stormfang"));

	private static final Map<UUID, Long> COOLDOWN = new ConcurrentHashMap<>();
	private static final long COOLDOWN_MS = 2500L;
	private static final double RAYCAST_RANGE = 40.0;

	public StormfangItem(class_5321<class_1792> key) {
		super(class_9886.field_52590, 5.0F, -1.6F, new class_1792.class_1793()
				.method_63686(key)
				.method_7894(class_1814.field_8904)
				.method_24359()
				// permanent enchantment shimmer — part of the "living blade" look
				.method_57349(class_9334.field_49641, Boolean.TRUE));
	}

	@Override
	public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
		// server authority — do nothing on the client
		if (world.field_9236) {
			return class_1269.field_5811;
		}

		long now = System.currentTimeMillis();
		Long last = COOLDOWN.get(user.method_5667());
		if (last != null && now - last < COOLDOWN_MS) {
			user.method_7353(
					class_2561.method_43471("item.stormfang.stormfang.cooldown").method_27692(class_124.field_1054),
					true);
			return class_1269.field_5814;
		}
		COOLDOWN.put(user.method_5667(), now);

		class_239 hit = stormfang$raycast(world, user);
		class_243 strike = hit.method_17783() == class_239.class_240.field_1333
				? user.method_33571().method_1019(user.method_5720().method_1021(20.0))
				: hit.method_17784();

		class_1538 bolt = new class_1538(class_1299.field_6112, world);
		bolt.method_5814(strike.field_1352, strike.field_1351 + 0.5, strike.field_1350);
		world.method_8649(bolt);

		if (hit instanceof class_3966 entityHit && entityHit.method_17782() == user) {
			// never smite yourself — still allow the visual, the bolt itself is harmless midair
			StormfangMod.LOGGER.debug("[Stormfang] Thunderclap aimed at own entity, offset applied");
		}

		if (world instanceof class_3218 serverLevel) {
			StormFx.thunderStrike(serverLevel, strike);
			serverLevel.method_43128(null, strike.field_1352, strike.field_1351, strike.field_1350,
					StormfangMod.THUNDER_CHARGE, class_3419.field_15252, 1.4F, 1.0F);
			StormfangMod.LOGGER.info("[Stormfang] Thunderclap by '{}' at {} {} {}",
					user.method_7334().getName(),
					String.format("%.1f", strike.field_1352),
					String.format("%.1f", strike.field_1351),
					String.format("%.1f", strike.field_1350));
		}

		user.method_23667(hand, true);
		return class_1269.field_52422;
	}

	/** Block+entity ray trace using primitives that are stable in 1.21.x Mojang mappings. */
	private static class_239 stormfang$raycast(class_1937 world, class_1657 user) {
		class_243 start = user.method_33571();
		class_243 end = start.method_1019(user.method_5720().method_1021(RAYCAST_RANGE));
		class_239 blockHit = world.method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, user));
		if (blockHit.method_17783() != class_239.class_240.field_1333) {
			return blockHit;
		}
		class_238 area = user.method_5829().method_18804(user.method_5720().method_1021(RAYCAST_RANGE)).method_1014(1.0);
		class_1297 nearest = null;
		class_243 nearestPos = null;
		double nearestDist = Double.MAX_VALUE;
		for (class_1297 e : world.method_8390(net.minecraft.class_1309.class, area,
				x -> x != user && x.method_5805() && x.method_5863())) {
			Optional<class_243> clip = e.method_5829().method_1014(e.method_5871()).method_992(start, end);
			if (clip.isPresent()) {
				double d = start.method_1025(clip.get());
				if (d < nearestDist) {
					nearestDist = d;
					nearest = e;
					nearestPos = clip.get();
				}
			}
		}
		return nearest != null ? new class_3966(nearest, nearestPos) : blockHit;
	}

	@Override
	public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
		tooltip.add(class_2561.method_43471("item.stormfang.stormfang.tooltip")
				.method_27695(class_124.field_1075, class_124.field_1056));
		tooltip.add(class_2561.method_43471("item.stormfang.stormfang.tooltip2")
				.method_27692(class_124.field_1080));
	}
}
